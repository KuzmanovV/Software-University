﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericSwapMethodStrings
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            List<int> values = new List<int>();

            for (int i = 0; i < n; i++)
            {
                int value = int.Parse(Console.ReadLine());
                values.Add(value);
            }

            int[] cmd = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int firstIndex = cmd[0];
            int secondIndex = cmd[1];

            Box<int> box = new Box<int>(values);
            
            box.Swap(values, firstIndex, secondIndex);

            foreach (var value in values)
            {
                Console.WriteLine($"{value.GetType()}: {value}");
            }
        }
    }
}
