﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person p = new Person();
            p.Name = "Pesho";
            p.Age = 20;

            Person g = new Person("Gosho", 18);
            Person s = new Person("Stamat", 43);

            Console.WriteLine(s.Name);
            Console.WriteLine(s.Age);
        }
    }
}
