﻿namespace EasterRaces.Repositories.Entities
{
    public class RaceRepository<IRace>: Repository<IRace>
    {
    }
}