﻿namespace EasterRaces.Repositories.Entities
{
    public class CarRepository<ICar>: Repository<ICar>
    {
    }
}