﻿namespace EasterRaces.Repositories.Entities
{
    public class DriverRepository<IDriver>: Repository<IDriver>
    {
    }
}