﻿namespace PersonInfo
{
    public interface IPet: IBirthable
    {
        public string Name { get; }
    }
}