﻿namespace PersonInfo
{
    public interface IRobot: IIdentifiable
    {
        string Model { get; }
    }
}