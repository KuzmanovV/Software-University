﻿namespace Telefony
{
    public interface IBrowsable
    {
        public void Browse(string site);
    }
}