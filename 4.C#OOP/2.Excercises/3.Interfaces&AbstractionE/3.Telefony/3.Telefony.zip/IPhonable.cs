﻿namespace Telefony
{
    public interface IPhonable
    {
        public void Call(string number);
    }
}