﻿namespace _7.MilitatyElite.Contracts
{
    public interface IRepair
    {
        string partName { get; }
        int hoursWorked { get; }
    }
}