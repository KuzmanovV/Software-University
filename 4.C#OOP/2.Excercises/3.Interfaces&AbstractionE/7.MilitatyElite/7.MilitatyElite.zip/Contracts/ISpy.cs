﻿namespace _7.MilitatyElite.Contracts
{
    public interface ISpy: ISoldier
    {
        int CodeNumber { get; }
    }
}