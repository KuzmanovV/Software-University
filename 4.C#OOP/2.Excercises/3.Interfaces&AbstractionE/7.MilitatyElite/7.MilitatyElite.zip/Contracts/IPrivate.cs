﻿namespace _7.MilitatyElite.Contracts
{
    public interface IPrivate: ISoldier
    {
        decimal Salary { get; }
    }
}