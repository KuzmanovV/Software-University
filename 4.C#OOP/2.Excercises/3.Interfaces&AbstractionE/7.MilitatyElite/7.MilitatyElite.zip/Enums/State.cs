﻿namespace _7.MilitatyElite.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}