﻿namespace _7.MilitatyElite.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}