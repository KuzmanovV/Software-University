﻿using _4.WildFarm.Abstract;

namespace _4.WildFarm.Models
{
    public class Meat: Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}