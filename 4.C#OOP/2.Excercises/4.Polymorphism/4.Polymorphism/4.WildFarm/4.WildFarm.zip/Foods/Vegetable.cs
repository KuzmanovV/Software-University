﻿using _4.WildFarm.Abstract;

namespace _4.WildFarm.Models
{
    public class Vegetable: Food
    {
        public Vegetable(int quantity) 
            : base(quantity)
        {
        }
    }
}