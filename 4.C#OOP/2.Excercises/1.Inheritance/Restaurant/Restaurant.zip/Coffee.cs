﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Coffee:HotBeverage
    {
        private double CoffeeMilliliters = 50;
        private decimal CoffeePrice = 3.50M;
        public Coffee(string name, decimal price, double milliliters, double	caffeine)
            : base(name, price, milliliters)
        {
            Caffeine = caffeine;
        }
        public double Caffeine { get; set; }
    }
}
