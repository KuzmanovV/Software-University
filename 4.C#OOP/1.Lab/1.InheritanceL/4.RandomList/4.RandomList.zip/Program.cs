﻿using System;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RandomList list = new RandomList();
            list.Add("A");
            list.Add("B");
            list.Add("C");

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(list.RandomString());
            }
        }
    }
}
