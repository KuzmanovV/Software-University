﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.Songs
{
   public class Song
    {
        public string TypeList { get; set; }
        public string Name { get; set; }
        public string Time { get; set; }
    }
}
