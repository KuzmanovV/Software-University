## 'workshop-01.zip'
The file 'workshop-01.zip' contains the already completed workshop taken from https://github.com/IliaIdakiev/softuni-ng-new/tree/master/workshop-components/ng-workshop

## 'changes.diff'
This files contains all the changes (ng update + styling).