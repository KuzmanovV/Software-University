# angular-course-2022-march-live
A repository for all the code written during the lectures of the 2022 SoftUni Angular Course
